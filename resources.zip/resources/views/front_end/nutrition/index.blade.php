@extends('layouts.main')
@section('content')
<div class="content" >
	<div class="main">

<div class="bread-crumbs" itemscope="" itemtype="http://schema.org/BreadcrumbList">
<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
<a itemprop="item" href="../index.htm"><i itemprop="name">Menu With Price</i></a>
<meta itemprop="position" content="1">
</span>
<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
<a href="index.htm" itemprop="item"><i itemprop="name">Nutrition</i></a>
<meta itemprop="position" content="2">
</span> </div>

<h1 style="color:blue;">Food Nutrition Value Calculator</h1>
<div class="ads ads-top"><div>
<style type="text/css">
.mwp_ads_1 { width: 100%; height: 252px; }
@media (min-width:768px) { .mwp_ads_1 { width: 100%; height: 100px; } }
</style>
<ins class="adsbygoogle mwp_ads_1" style="display:inline-block" data-ad-client="ca-pub-6371063963738592" data-ad-slot="8669735678"></ins>
<script async="" src="../pagead/js/f.txt" type="8d8b93a42c3da1e79537afe6-text/javascript"></script>
<script type="8d8b93a42c3da1e79537afe6-text/javascript">
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div>

<div class="category">
<a href="index.htm" class="active"  style="background-color:blue;">Popular Brands</a>
<a href="a/index.htm"  style="background-color:blue;">A</a><a href="b/index.htm"  style="background-color:blue;">B</a><a href="c/index.htm"  style="background-color:blue;">C</a><a href="d/index.htm"  style="background-color:blue;">D</a><a href="e/index.htm"  style="background-color:blue;">E</a><a href="f/index.htm"  style="background-color:blue;">F</a><a href="g/index.htm"  style="background-color:blue;">G</a><a href="h/index.htm"  style="background-color:blue;">H</a><a href="i/index.htm"  style="background-color:blue;">I</a><a href="j/index.htm"  style="background-color:blue;">J</a><a href="k/index.htm"  style="background-color:blue;">K</a><a href="l/index.htm"  style="background-color:blue;">L</a><a href="m/index.htm"  style="background-color:blue;">M</a><a href="n/index.htm"  style="background-color:blue;">N</a><a href="o/index.htm"  style="background-color:blue;">O</a><a href="p/index.htm"  style="background-color:blue;">P</a><a href="q/index.htm"  style="background-color:blue;">Q</a><a href="r/index.htm"  style="background-color:blue;">R</a><a href="s/index.htm"  style="background-color:blue;">S</a><a href="t/index.htm"  style="background-color:blue;">T</a><a href="u/index.htm"  style="background-color:blue;">U</a><a href="v/index.htm"  style="background-color:blue;">V</a><a href="w/index.htm"  style="background-color:blue;">W</a><a href="y/index.htm"  style="background-color:blue;">Y</a><a href="z/index.htm"  style="background-color:blue;">Z</a><a href="1/index.htm"  style="background-color:blue;">#</a> </div>


<ul class="menu-list category-menu">
<li><a href="nutrition/applebees" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Applebee's</a></li> <li><a href="arbys/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Arby's</a></li> <li><a href="black-bear-diner/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Black Bear Diner</a></li> <li><a href="bojangles/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Bojangles'</a></li> <li><a href="burger-king/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Burger King</a></li> <li><a href="captain-ds-seafood/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Captain D's Seafood</a></li> <li><a href="carls-jr/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Carl's Jr.</a></li> <li><a href="chick-fil-a/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Chick-fil-A</a></li> <li><a href="chicken-express/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Chicken Express</a></li> <li><a href="chipotle-mexican-grill/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Chipotle Mexican Grill</a></li> <li><a href="churchs-chicken/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Church's Chicken</a></li> <li><a href="cook-out/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Cook Out</a></li> <li><a href="culvers/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Culver's</a></li> <li><a href="dairy-queen/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Dairy Queen</a></li> <li><a href="del-taco/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Del Taco</a></li> <li><a href="dominos-pizza/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Domino's Pizza</a></li> <li><a href="dunkin-donuts/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Dunkin' Donuts</a></li> <li><a href="el-pollo-loco/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">El Pollo Loco</a></li></ul>
<div class="ads ads-center"><div style="text-align:center;">
<style type="text/css">
.mwp_ads_2 { width: 100%; height: 250px; }
@media (min-width:336px) { .mwp_ads_2 { width: 100%; height: 280px; } }
@media (min-width:768px) { .mwp_ads_2 { width: 100%; height: 100px; } }
</style>

<ins class="adsbygoogle mwp_ads_2" style="display:inline-block" data-ad-client="ca-pub-6371063963738592" data-ad-slot="4099935279"></ins>
<script async="" src="../pagead/js/f.txt" type="8d8b93a42c3da1e79537afe6-text/javascript"></script>
<script type="8d8b93a42c3da1e79537afe6-text/javascript">
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div>
<ul class="menu-list category-menu"> <li><a href="firehouse-subs/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Firehouse Subs</a></li> <li><a href="five-guys/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Five Guys</a></li> <li><a href="golden-corral/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Golden Corral</a></li> <li><a href="hardees/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Hardee's</a></li> <li><a href="ihop/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">IHOP</a></li> <li><a href="jack-in-the-box/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Jack in the Box</a></li> <li><a href="jersey-mikes-subs/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Jersey Mike's Subs</a></li> <li><a href="jimmy-johns/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Jimmy John's</a></li> <li><a href="kfc/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">KFC</a></li> <li><a href="krispy-kreme/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Krispy Kreme</a></li> <li><a href="little-caesars-pizza/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Little Caesars Pizza</a></li> <li><a href="long-john-silvers/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Long John Silver's</a></li> <li><a href="marcos-pizza/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Marco's Pizza</a></li> <li><a href="mcdonalds/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">McDonald's</a></li> <li><a href="moes-southwest-grill/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Moe's Southwest Grill</a></li> <li><a href="outback-steakhouse/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Outback Steakhouse</a></li> <li><a href="panda-express/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Panda Express</a></li> <li><a href="panera-bread/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Panera Bread</a></li> <li><a href="papa-johns-pizza/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Papa John's Pizza</a></li> <li><a href="papa-murphys/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Papa Murphy's</a></li> <li><a href="pizza-hut/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Pizza Hut</a></li> <li><a href="popeyes-louisiana-kitchen/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Popeyes Louisiana Kitchen</a></li> <li><a href="qdoba-mexican-grill/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Qdoba</a></li> <li><a href="ruby-tuesday/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Ruby Tuesday</a></li> <li><a href="sheetz/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Sheetz</a></li> <li><a href="sizzler/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Sizzler</a></li> <li><a href="smokey-bones/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Smokey Bones</a></li> <li><a href="smoothie-king/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Smoothie King</a></li> <li><a href="sonic/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Sonic Drive-In</a></li> <li><a href="starbucks/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Starbucks Coffee</a></li> <li><a href="steak-n-shake/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Steak 'n Shake</a></li> <li><a href="subway/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Subway</a></li> <li><a href="taco-bell/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Taco Bell</a></li> <li><a href="taco-bueno/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Taco Bueno</a></li> <li><a href="taco-johns/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Taco John's</a></li> <li><a href="tim-hortons/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Tim Hortons</a></li> <li><a href="wawa/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Wawa</a></li> <li><a href="wendys/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Wendy's</a></li> <li><a href="whataburger/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Whataburger</a></li> <li><a href="white-castle/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">White Castle</a></li> <li><a href="wingstop/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Wingstop</a></li> <li><a href="zaxbys/index.htm" style="border:1px solid blue;text-align: center;font-size:18px;font-family:Arial, Helvetica, sans-serif;">Zaxby's</a></li>
</ul>

<div class="ads ads-bottom"><div>
<style type="text/css">
.mwp_ads_3 { width: 100%; height: 250px; }
@media (min-width:336px) { .mwp_ads_3 { width: 100%; height: 280px; } }
@media (min-width:768px) { .mwp_ads_3 { width: 100%; height: 100px; } }
</style>

<ins class="adsbygoogle mwp_ads_3" style="display:inline-block" data-ad-client="ca-pub-6371063963738592" data-ad-slot="1006868077"></ins>
<script async="" src="../pagead/js/f.txt" type="8d8b93a42c3da1e79537afe6-text/javascript"></script>
<script type="8d8b93a42c3da1e79537afe6-text/javascript">
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div>


</div>
</div>
@endsection