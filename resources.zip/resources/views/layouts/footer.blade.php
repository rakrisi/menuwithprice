<div class="footer">
<div class="ft-inner" style="letter-spacing: 5px;text-align: center;">
<h2>General Information</h2>
<a href="/about">About Us |</a>
<a href="/contact">Contact Us |</a>
<a href="/privacy">Privacy Policy |</a>
<a href="/term">Terms of Use</a> <p>&#169; 2021 Website. </p>
</div>
</div>



<script src="{{ asset('user/front_end/js/jquery.min.js?v-1')}}" type="32d3d962bf56aa0734ff3580-text/javascript"></script>
<script type="32d3d962bf56aa0734ff3580-text/javascript">
    var address='2401:4900:30c7:6262:2ccb:3112:2973:6348' ? '2401:4900:30c7:6262:2ccb:3112:2973:6348':'';
    </script>
<script src="{{ asset('user/front_end/js/main.js?v-88')}}" type="32d3d962bf56aa0734ff3580-text/javascript"></script>
<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="32d3d962bf56aa0734ff3580-|49" defer=""></script></body>
</html>